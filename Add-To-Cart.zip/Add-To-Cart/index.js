let record = [
    { id: 1, name: "Grilled Sandwich", price: 200, qnt: 1, image: "image/greer-sandwitch.avif" },
    { id: 2, name: "Combo", price: 400, qnt: 1, image: "image/combo.webp" },
    { id: 3, name: "Burger-Drink", price: 300, qnt: 1, image: "image/burger-drink.jpg" },
    { id: 4, name: "Pizza", price: 500, qnt: 1, image: "image/pizzo.jpeg" },
    { id: 5, name: "Burger", price: 400, qnt: 1, image: "image/burger.jpg" },
    { id: 6, name: "Vadapav", price: 50, qnt: 1, image: "image/vadapav.jpg" }
];









